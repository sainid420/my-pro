<?php
// login.php

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Replace with real credentials
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $error = "Invalid credentials.";
    }
}
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
            /* Replace this URL with the new background image URL */
            /* background-image: url('https://example.com/new-background.jpg'), linear-gradient(to bottom, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.9)); */
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background:linear-gradient(to bottom, rgba(238, 204, 204, 0.6), rgba(26, 22, 22, 0.9));
            
        }

        .container {
            background-color: rgba(0, 0, 0, 0.7); /* Darker background for the form */
            padding: 40px;
            border-radius: 10px;
            width: 350px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.6);
        }

        .container h2 {
            color: #fff;
            margin-bottom: 20px;
            font-size: 36px;
            text-transform: uppercase;
            font-weight: bold;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
            background-color: rgba(255, 255, 255, 0.8);
            transition: background-color 0.3s;
        }

        input[type="text"]:focus, input[type="password"]:focus {
            background-color: rgba(255, 255, 255, 1);
            outline: none;
            border-color: #4CAF50;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        p {
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        /* Error Message Style */
        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }
    </style>
    <script>
        // Apply Action function
function applyAction() {
    // alert("ressOk ");
    if(confirm("press ok to register")){
        window.location.href="index.php";
    }
}
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>

    <div class="container">
        <h2>Admin Login</h2>
        
        <?php if (isset($error)): ?>
            <p class="error-message"><?= $error ?></p>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
        
            <button type="submit">Login</button>
            <button type="button" onclick="applyAction()">Apply job</button>
        </form>
    </div>
</body>
</html> 
