 <?php
// if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['fileToUpload'])) {
//     $targetDir = "filetoupload"; // Directory to save uploaded files
//     $targetFile = $targetDir . basename($_FILES["fileToUpload"]["name"]);
//     $uploadOk = 1;
    

    // Check if file already exists
    // if (file_exists($targetFile)) {
    //     echo "Sorry, file already exists.";
    //     $uploadOk = 0;
    // }

    // Check file size (limit to 2MB)
    // if ($_FILES["fileToUpload"]["size"] > 5000000) {
    //     echo "Sorry, your file is too large.";
    //     $uploadOk = 0;
    // }
    // $fileType=strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Allow certain file formats
    // if (!in_array($fileType,['jpg','jpeg','gif','pdf','txt','docx','pptx','png']))  {
    //     echo "Sorry, only JPG, JPEG, PNG, and PDF files are allowed.";
    //     $uploadOk = 0;
    // }

    // Check if $uploadOk is set to 0 by an error
    // if ($uploadOk == 0) {
    //     echo "Sorry, your file was not uploaded.";
    // } else {
        // Try to upload file
//         if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFile)) {
//             echo "The file " . basename($_FILES["fileToUpload"]["name"]) . " has been uploaded.";
//         } else {
//             echo "Sorry, there was an error uploading your file.";
//         }
//     }
// }
?>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* CSS styles for professional form design */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .registration-form {
            background-color: #fff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        h1 {
            text-align: center;
            color: #333;
            font-size: 2em;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
            color: #555;
            
        }

        input[type="text"], input[type="email"], input[type="date"], select {
            width: 100%;
            padding: 12px;
            margin: 8px 0 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            color: #333;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="email"]:focus, input[type="date"]:focus, select:focus {
            border-color: #4CAF50;
            outline: none;
        }

        input[type="radio"] {
            margin-right: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group-radio {
            margin-bottom: 20px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .form-group select {
            padding: 12px;
        }

        /* Adding spacing for radio buttons */
        .form-group-radio label {
            margin-right: 20px;
        }

        /* Improve the layout of the form */
        .form-group-radio {
            display: flex;
            justify-content: space-between;
            align-items: center;
            ;
        }

        .form-group select, .form-group input {
            box-sizing: border-box;
        }

        /* Mobile responsiveness */
        @media (max-width: 768px) {
            .registration-form {
                padding: 20px;
            }

            h1 {
                font-size: 1.5em;
            }

            button {
                padding: 10px 15px;
            }
        }

    </style>
</head>
<body>
    <div class="registration-form">
        <h1>Registration Form</h1>
        <form action="#" method="post"> -->
            <!-- First Name -->
            <!-- <div class="form-group">
                <label for="firstname">First Name:</label>
                <input type="text" id="firstname" name="firstname" placeholder="First Name" required>
            </div> -->

            <!-- Last Name -->
            <!-- <div class="form-group">
                <label for="lastname">Last Name:</label>
                <input type="text" id="lastname" name="lastname" placeholder="Last Name" required>
            </div> -->
            

            <!-- Email -->
            <!-- <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Email" required>
            </div> -->

            <!-- Date of Birth -->
            <!-- <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="date" placeholder="Date of Birth" required>
            </div> -->

            <!-- Gender -->
            <!-- <div class="form-group-radio">
                <label>Gender:</label>
                <label>
                    <input type="radio" name="gender" value="Male"> Male
                </label>
                <label>
                    <input type="radio" name="gender" value="Female"> Female
                </label>
            </div> -->

            <!-- Choose Course -->
            <!-- <div class="form-group">
                <label for="course">Choose Course:</label>
                <select id="course" name="course" required>
                    <option value="">--Select--</option>
                    <option value="Frontend Developer">Frontend Developer</option>
                    <option value="Backend Developer">Backend Developer</option>
                    <option value="Full Stack Developer">Full Stack Developer</option>
                    <option value="UI/UX Designer">UI/UX Designer</option>
                    <option value="Product Manager">Product Manager</option>
                    <option value="Data Scientist">Data Scientist</option>
                    <option value="DevOps Engineer">DevOps Engineer</option>
                    <option value="Mobile App Developer">Mobile App Developer</option>
                    <option value="Software Engineer">Software Engineer</option>
                    <option value="Cloud Architect">Cloud Architect</option>
                    <option value="Javascript Developer">Javascript Developer</option>
                    <option value="Database Administrator">Database Administrator</option>
                    <option value="Cybersecurity Specialist">Cybersecurity Specialist</option>
                    <option value="AI Engineer">AI Engineer</option>
                    <option value="Network Engineer">Network Engineer</option>
                    <option value="QA Engineer">QA Engineer</option>
                    <option value="Blockchain Developer">Blockchain Developer</option>
                    <option value="Graphic Designer">Graphic Designer</option>
                    <option value="Content Writer">Content Writer</option>
                    <option value="Marketing Manager">Marketing Manager</option>
                    <option value="Business Analyst">Business Analyst</option>
                    <option value="Sales Manager">Sales Manager</option>
                    <option value="System Administrator">System Administrator</option>
                </select>
            </div> -->

            <!-- Location -->
            <!-- <div class="form-group">
                <label for="location">Location:</label>
                <select id="location" name="location" required>
                    <option value="">--Select--</option>
                    <option value="Himachal">Himachal</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Goa">Goa</option>
                    <option value="Rajasthan">Rajasthan</option> -->
                <!-- </select>
            </div>
            <div class="registration-form">
    </form>
        <form action="#" method="post" enctype="multipart/form-data"> -->
            <!-- Existing form fields -->

            <!-- File Upload -->
            <!-- <div class="form-group">
                <label for="filetoupload">Upload File:</label>
                <input type="file" id="filetoupload" name="fileToUpload" required>
            </div> -->

            <!-- Submit Button -->
             <!-- <input type="submit" value="Upload File" id="fileToUpload">
            <button type="submit" name="submit">Submit</button>
        </form>
    </div>

             -->
<!-- </body>
</html> -->



<?php

$conn=mysqli_connect($host="localhost",$user="root",$password="")or die(mysqli_error($conn));
// echo"database connected<br>";
// $sql=mysqli_query($conn,"create database Resume")or die(mysqli_error($conn));
// echo"database created <br>";


$sql=mysqli_select_db($conn,"Resume")or die(mysqli_error($conn));
// $tab=mysqli_query($conn,"create table  dhankaur(Firstname varchar(40),Lastname varchar(50),email varchar(50), DOB date,gender varchar(20),Job varchar(60),Location varchar(40),files varchar(50))")or die(mysqli_error($conn));
// echo"table created";
$conn=mysqli_connect($host="localhost",$user="root",$password="", $dbname="Resume")or die(mysqli_error($conn));
// echo"table database";
if (isset($_POST['sub']))
 {
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $dob = mysqli_real_escape_string($conn, $_POST['date']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $job = mysqli_real_escape_string($conn, $_POST['job']);
    $Location = mysqli_real_escape_string($conn, $_POST['location']);
    $files = mysqli_real_escape_string($conn, $_POST['files']);

    // $ins=mysqli_query($conn,"INSERT INTO  values(' $firstname',' $lastname',   '$email', $dob, '$gender', '$job','$Location','$files' ")or die(mysqli_error($conn));
    //   echo " <script>
    //                alert('Data inserted successfully!');
    //              </script>";
  


// $ins=mysqli_query($conn,"INSERT INTO vendor value('$username','$email',$shop,$password)")or die(mysqli_error($conn));
// echo "data inserted";



$check_query = mysqli_query($conn, "SELECT * FROM dhankaur WHERE email = '$email'");
if (mysqli_num_rows($check_query) > 0) {
    // ID already exists, show an alert
    echo "<script>
            alert('ID already exists!');
          </script>";
} else {
    // Insert the data if ID does not exist
    $ins = mysqli_query($conn, "INSERT INTO dhankaur values(' $firstname',' $lastname',   '$email', $dob, '$gender', '$job','$Location', 
    '$files')");
    if ($ins) {
        echo "<script>
                alert('Data inserted successfully!');
              </script>";
    } else {
        echo "<script>
                alert('Error inserting data!');
              </script>";
    }
}
 }

 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* CSS styles for professional form design */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .registration-form {
            background-color: #fff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        h1 {
            text-align: center;
            color: #333;
            font-size: 2em;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
            color: #555;
        }

        input[type="text"], input[type="email"], input[type="date"], select {
            width: 100%;
            padding: 12px;
            margin: 8px 0 20px;
            border: 1px solid #ccc;
            
            border-radius: 4px;
            font-size: 16px;
            color: #333;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="email"]:focus, input[type="date"]:focus, select:focus {
            border-color: #4CAF50;
            outline: none;
        }

        input[type="radio"] {
            margin-right: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group-radio {
            margin-bottom: 20px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .form-group select {
            padding: 12px;
        }

        /* Adding spacing for radio buttons */
        .form-group-radio label {
            margin-right: 20px;
        }

        /* Improve the layout of the form */
        .form-group-radio {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .form-group select, .form-group input {
            box-sizing: border-box;
        }

        /* Mobile responsiveness */
        @media (max-width: 768px) {
            .registration-form {
                padding: 20px;
            }

            h1 {
                font-size: 1.5em;
            }

            button {
                padding: 10px 15px;
            }
        }

    </style>
</head>
<body>
    <div class="registration-form">
        <h1>Registration Form</h1>
        <form action="#" method="post">
            <!-- First Name -->
            <div class="form-group">
                <label for="firstname">First Name:</label>
                <input type="text" id="firstname" name="firstname" placeholder="First Name" required>
            </div>

            <!-- Last Name -->
            <div class="form-group">
                <label for="lastname">Last Name:</label>
                <input type="text" id="lastname" name="lastname" placeholder="Last Name" required>
            </div>

            <!-- Email -->
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Email" required>
            </div>

            <!-- Date of Birth -->
            <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="date" placeholder="Date of Birth" required>
            </div>

            <!-- Gender -->
            <div class="form-group-radio">
                <label>Gender:</label>
                <label>
                    <input type="radio" name="gender" value="Male"> Male
                </label>
                <label>
                    <input type="radio" name="gender" value="Female"> Female
                </label>
            </div>

            <!-- Choose Course -->
            <div class="form-group">
                <label for="course">Choose Job</label>
                <select id="course" name="job" required>
                    <option value="">--Select--</option>
                    <option value="Frontend Developer">Frontend Developer</option>
                    <option value="Backend Developer">Backend Developer</option>
                    <option value="Full Stack Developer">Full Stack Developer</option>
                    <option value="UI/UX Designer">UI/UX Designer</option>
                    <option value="Product Manager">Product Manager</option>
                    <option value="Data Scientist">Data Scientist</option>
                    <option value="DevOps Engineer">DevOps Engineer</option>
                    <option value="Mobile App Developer">Mobile App Developer</option>
                    <option value="Software Engineer">Software Engineer</option>
                    <option value="Cloud Architect">Cloud Architect</option>
                    <option value="Javascript Developer">Javascript Developer</option>
                    <option value="Database Administrator">Database Administrator</option>
                    <option value="Cybersecurity Specialist">Cybersecurity Specialist</option>
                    <option value="AI Engineer">AI Engineer</option>
                    <option value="Network Engineer">Network Engineer</option>
                    <option value="QA Engineer">QA Engineer</option>
                    <option value="Blockchain Developer">Blockchain Developer</option>
                    <option value="Graphic Designer">Graphic Designer</option>
                    <option value="Content Writer">Content Writer</option>
                    <option value="Marketing Manager">Marketing Manager</option>
                    <option value="Business Analyst">Business Analyst</option>
                    <option value="Sales Manager">Sales Manager</option>
                    <option value="System Administrator">System Administrator</option>
                </select>
            </div>

            <!-- Location -->
            <div class="form-group">
                <label for="location">Location:</label>
                <select id="location" name="location" required>
                    <option value="">--Select--</option>
                    <option value="Himachal">Himachal</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Goa">Goa</option>
                    <option value="Rajasthan">Rajasthan</option>
                </select>
            </div>

            <input type="file" id="filetoupload" name="files" required>

            <!-- Submit Button -->
            <button type="submit" name="sub">Submit</button>
        </form>
    </div>
</body>
</html>

