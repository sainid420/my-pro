<?php
require_once 'db.php';

$stmt = $conn->prepare("SELECT * FROM jobs ORDER BY created_at DESC");
$stmt->execute();
$jobs_result = $stmt->get_result();
$jobs = $jobs_result->fetch_all(MYSQLI_ASSOC); // Fetch all jobs as an array
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Board</title>
    <style>
        /* General styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .search-bar {
            max-width: 800px;
            margin: 20px auto;
            display: flex;
            gap: 10px;
        }

        .search-bar input, .search-bar select, .search-bar button {
            padding: 10px;
            font-size: 16px;
        }

        .job-listings {
            display: flex;
            flex-direction: column;
            gap: 20px;
            max-width: 800px;
            margin: 20px auto;
            padding: 10px;
        }

        .job-listing {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .job-listing h3 {
            margin: 0 0 10px;
            color: #333;
        }

        .job-listing p {
            margin: 5px 0;
            color: #555;
        }

        .apply-btn {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 15px;
            background-color: #4CAF50;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
        }

        .apply-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <!-- Search Bar -->
    <div class="search-bar">
        <input type="text" id="jobSearch" placeholder="Search jobs by title...">
        <input type="text" id="locationSearch" placeholder="Search jobs by location...">
        <button onclick="filterJobs()">Search</button>
    </div>

    <!-- Job Listings -->
    <div class="job-listings" id="jobListings">
        <?php foreach ($jobs as $job): ?>
            <div class="job-listing" data-title="<?= strtolower($job['title']) ?>" data-location="<?= strtolower($job['location']) ?>">
                <h3><?= htmlspecialchars($job['title']) ?></h3>
                <p><?= htmlspecialchars($job['description']) ?></p>
                <p><strong>Location:</strong> <?= htmlspecialchars($job['location']) ?></p>
                <p><strong>Type:</strong> <?= htmlspecialchars($job['job_type']) ?></p>
                <a href="project2.php" class="apply-btn">Apply Job</a>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        function filterJobs() {
            const jobSearch = document.getElementById('jobSearch').value.toLowerCase();
            const locationSearch = document.getElementById('locationSearch').value.toLowerCase();
            const jobListings = document.querySelectorAll('.job-listing');

            jobListings.forEach(job => {
                const title = job.getAttribute('data-title');
                const location = job.getAttribute('data-location');

                if (title.includes(jobSearch) && location.includes(locationSearch)) {
                    job.style.display = 'block';
                } else {
                    job.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>