<?php 
$conn=mysqli_connect($host="localhost",$user="root",$password="",$dbname="Jobs")or die(mysqli_error($conn));
echo "database connected";

$del=mysqli_query($conn,"delete from student where * marks")or die(mysqli_error($conn));
echo "data deleted";
$upd=mysqli_query($conn,"update student set name='star' where id= 105")or die(mysqli_error($conn));
echo "data updated";
?>