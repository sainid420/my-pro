<?php
// admin.php
session_start();

// Simple admin authentication (replace with proper login mechanism in production)
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");  // Redirect to login page if not logged in
    exit;
}

require_once 'db.php'; // Include database connection

// Handle job insertion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_job'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $job_type = $_POST['job_type'];

    $stmt = $conn->prepare("INSERT INTO jobs (title, description, location, job_type) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $title, $description, $location, $job_type);
    $stmt->execute();

    // After the job is added, redirect to the home page (admin.php)
    header("Location: admin.php");  // Redirect to the home page
    exit;  // Make sure the script stops executing after redirect
}

// Handle job update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_job'])) {
    $job_id = $_POST['job_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $job_type = $_POST['job_type'];

    $stmt = $conn->prepare("UPDATE jobs SET title = ?, description = ?, location = ?, job_type = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $title, $description, $location, $job_type, $job_id);
    $stmt->execute();

    // After the job is updated, redirect to the admin page
    header("Location: admin.php");  // Redirect to the admin page
    exit;
}

// Handle job deletion
if (isset($_GET['delete'])) {
    $job_id = $_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM jobs WHERE id = ?");
    $stmt->bind_param("i", $job_id);
    $stmt->execute();

    // After the job is deleted, redirect to the admin page
    header("Location: admin.php");  // Redirect to the admin page
    exit;
}

// Fetch all jobs
$stmt = $conn->prepare("SELECT * FROM jobs ORDER BY created_at DESC");
$stmt->execute();
$jobs_result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        /* General Styles */
        body {
            background-image: url('https://png.pngtree.com/thumb_back/fh260/back_pic/03/76/37/2257bea537b28e6.jpg'), 
                              url('https://www.example.com/another-background.jpg');
            background-size: cover;
            background-position: center center, center center;
            height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            color: #fff;
            background-blend-mode: overlay;  /* This will blend both images */
            background-color: rgba(0, 0, 0, 0.4);  /* Optional: adds a dark overlay */
            
        }

        .container {
            background-color: rgba(240, 237, 237, 0.7);
            padding: 40px;
            border-radius: 10px;
            width: 80%;
            max-width: 900px;
            margin: 20px auto;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }

        h1, h2 {
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
            
        }

        /* Form Styling */
        form input, form select, form textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            background-color: rgba(177, 171, 171, 0.7);
            transition: all 0.3s ease;
        }

        form input:focus, form select:focus, form textarea:focus {
            border-color: #4CAF50;
            outline: none;
        }

        form button {
            padding: 12px 20px;
            background-color:black ; 
            color  :white;
            border-radius: 10px;
            
                    }

        form button:hover {
            background-color:white;
            color:black;
        }

        /* Table Styling */
        table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
            text-align: left;
        }

        table th, table td {
            padding: 15px;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #D3D3D3;
            color: #fff;
        }

        table tbody tr:nth-child(even) {
            background-color: #222b3d;
            color:white;
        }

        table tbody tr:hover {
            background-color:white;
            color:black;
        }

        /* Actions Styling */
        .actions a {
            text-decoration: none;
            padding: 8px 15px;
            margin: 0 5px;
            border-radius: 5px;
            color: #fff;
            transition: background-color 0.3s ease;
        }

        .actions .edit-btn {
            background-color:rgb(15, 15, 15);
            color:white;
            border:2px solid white;
        }

        .actions .edit-btn:hover {
            background-color:rgb(252, 251, 251);
            color:black;
            border:2px solid black;
           
        }

        .actions .delete-btn {
            background-color:rgb(252, 249, 248);
            color:black;
            border:2px solid black;
        }

        .actions .delete-btn:hover {
            background-color:rgb(10, 10, 10);
            color:white;
            border:2px solid white;
        }
        .apply-btn {
            background-color:rgb(15, 15, 15);
            color:white;
            border:2px solid white;
        }

        .apply-btn:hover {
            background-color:white;
            color:black;
            border:2px solid black;
            box-shadow:0px 0px 10px black;
        }


        /* Responsive Styles */
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }

            h1, h2 {
                font-size: 24px;
            }

            table th, table td {
                padding: 10px;
            }
        }
    </style>
    <script>
        // Apply Action function
function applyAction() {
    // alert("ressOk ");
    if(confirm("press ok to register")){
        window.location.href="project2.php";
    }
}
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Job Board</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container">
        <header>
            <h1>Admin Dashboard</h1>
        </header>

        <h2>Add New Job</h2>
        <form method="POST">
            <input type="text" name="title" placeholder="Job Title" required>
            <textarea name="description" placeholder="Job Description" required></textarea>
            <input type="text" name="location" placeholder="Job Location" required>
            <select name="job_type" required>
                <option value="Full-Time">Full-Time</option>
                <option value="Part-Time">Part-Time</option>
                <option value="Remote">Remote</option>
            </select>
            <button type="submit" name="add_job">Add Job</button>
        </form>

        <h2>Manage Jobs</h2>
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($job = $jobs_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $job['title'] ?></td>
                        <td><?= $job['location'] ?></td>
                        <td><?= $job['job_type'] ?></td>
                        <td class="actions">
                            <a href="admin.php?edit=<?= $job['id'] ?>" class="edit-btn">Edit</a>
                            <a href="admin.php?delete=<?= $job['id'] ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this job?')">Delete</a>
                          
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <?php if (isset($_GET['edit'])): ?>
            <?php
            // Fetch the job details for editing
            $job_id = $_GET['edit'];
            $stmt = $conn->prepare("SELECT * FROM jobs WHERE id = ?");
            $stmt->bind_param("i", $job_id);
            $stmt->execute();
            $job = $stmt->get_result()->fetch_assoc();
            ?>
            <h2>Edit Job</h2>
            <form method="POST">
                <input type="hidden" name="job_id" value="<?= $job['id'] ?>">
                <input type="text" name="title" value="<?= $job['title'] ?>" required>
                <textarea name="description" required><?= $job['description'] ?></textarea>
                <input type="text" name="location" value="<?= $job['location'] ?>" required>
                <select name="job_type" required>
                    <option value="Full-Time" <?= $job['job_type'] == 'Full-Time' ? 'selected' : '' ?>>Full-Time</option>
                    <option value="Part-Time" <?= $job['job_type'] == 'Part-Time' ? 'selected' : '' ?>>Part-Time</option>
                    <option value="Remote" <?= $job['job_type'] == 'Remote' ? 'selected' : '' ?>>Remote</option>
                </select>
                <button type="submit" name="update_job">Update Job</button>
            </form>
        <?php endif; ?>
    </div>

</body>
</html>
