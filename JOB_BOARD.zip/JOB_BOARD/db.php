<?php
// db.php - Database connection file

$servername = "localhost";  // Adjust to your database settings
$username = "root";         // Your database username
$password = "";             // Your database password
$dbname = "jobs";      // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// $tab=mysqli_query($conn,"CREATE TABLE jobs (
//     id INT AUTO_INCREMENT PRIMARY KEY,
//     title VARCHAR(255) NOT NULL,
//     description TEXT NOT NULL,
//     location VARCHAR(255) NOT NULL,
//     job_type VARCHAR(255) NOT NULL,
//     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
// )
// ")or die(mysqli_error($conn));
// echo "table created";
?>
