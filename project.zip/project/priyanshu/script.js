// Array of courses data (20 courses)
const courses = [
    { id: 'html', title: 'HTML Basics', description: 'Learn the structure of the web with HTML.' },
    { id: 'css', title: 'CSS Essentials', description: 'Style your pages beautifully with CSS.' },
    { id: 'js', title: 'JavaScript Fundamentals', description: 'Make your site interactive with JavaScript.' },
    { id: 'python', title: 'Python for Beginners', description: 'Learn the basics of Python programming.' },
    { id: 'java', title: 'Java Programming', description: 'Master Java programming and object-oriented design.' },
    { id: 'ruby', title: 'Ruby on Rails', description: 'Develop web applications using Ruby on Rails.' },
    { id: 'nodejs', title: 'Node.js for Beginners', description: 'Understand server-side programming with Node.js.' },
    { id: 'react', title: 'React.js Basics', description: 'Build dynamic web apps using React.' },
    { id: 'angular', title: 'Angular Fundamentals', description: 'Learn to build dynamic websites with Angular.' },
    { id: 'vuejs', title: 'Vue.js Essentials', description: 'Get started with Vue.js for front-end development.' },
    { id: 'git', title: 'Git and GitHub Basics', description: 'Learn how to use version control with Git and GitHub.' },
    { id: 'database', title: 'SQL Database Fundamentals', description: 'Learn how to manage databases with SQL.' },
    { id: 'mongodb', title: 'MongoDB for Beginners', description: 'Work with NoSQL databases using MongoDB.' },
    { id: 'swift', title: 'Swift for Beginners', description: 'Start programming for iOS with Swift.' },
    { id: 'csharp', title: 'C# Programming', description: 'Learn C# programming for Windows development.' },
    { id: 'typescript', title: 'TypeScript Basics', description: 'Enhance JavaScript with TypeScript.' },
    { id: 'flutter', title: 'Flutter for Mobile Apps', description: 'Create mobile apps with Flutter.' },
    { id: 'kotlin', title: 'Kotlin for Android Development', description: 'Build Android apps with Kotlin.' },
    { id: 'go', title: 'Go Programming', description: 'Learn the Go language for efficient coding.' },
    { id: 'rust', title: 'Rust Programming', description: 'Master the Rust language for safe and fast programming.' }
  ];
  
  // Function to populate course list dynamically
  function loadCourses() {
    const courseContainer = document.getElementById('courseContainer');
    
    // Loop through all courses and create course elements
    courses.forEach(course => {
      const courseDiv = document.createElement('div');
      courseDiv.classList.add('course');
      courseDiv.onclick = () => viewCourse(course.id);
  
      courseDiv.innerHTML = `
        <h3>${course.title}</h3>
        <p>${course.description}</p>
      `;
      
      courseContainer.appendChild(courseDiv);
    });
  }
  
  // Function to display course details when clicked
  function viewCourse(courseId) {
    const course = courses.find(c => c.id === courseId);
    const detail = document.getElementById('courseDetail');
    detail.innerHTML = `
      <h2>${course.title}</h2>
      <p>${course.description}</p>
      <ul>
        <li>Introduction</li>
        <li>Lesson 1</li>
        <li>Lesson 2</li>
        <li>Practice Project</li>
      </ul>
    `;
  }
  
  // Call loadCourses function when the page loads
  window.onload = loadCourses;
  