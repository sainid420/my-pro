// Mock job data
const jobs = [
    { title: 'Frontend Developer', location: 'Himachal', type: 'Full-Time', description: 'Develop amazing UI for apps.' },
    { title: 'Frontend Developer', location: 'Himachal', type: 'part-Time', description: 'Develop amazing UI for apps.' },
    { title: 'Backend Developer', location: 'Kerala', type: 'Part-Time', description: 'Build APIs for applications.' },
    { title: 'Backend Developer', location: 'Kerala', type: 'Full-Time', description: 'Build APIs for applications.' },
    { title: 'Full Stack Developer', location: 'Gujarat', type: 'Remote', description: 'Work on both frontend and backend.' },
    { title: 'UI/UX Designer', location: 'Haryana', type: 'Full-Time', description: 'Design user-friendly interfaces for web and mobile apps.' },
    { title: 'Product Manager', location: 'Punjab', type: 'Full-Time', description: 'Oversee product development lifecycle from concept to launch.' },
    { title: 'Data Scientist', location: 'Jharkhand', type: 'Remote', description: 'Analyze large datasets to derive actionable insights for businesses.' },
    { title: 'DevOps Engineer', location: 'Goa', type: 'Full-Time', description: 'Ensure smooth deployment and operation of applications in production.' },
    { title: 'Mobile App Developer', location: 'Kerala', type: 'Full-Time', description: 'Develop mobile apps for iOS and Android platforms.' },
    { title: 'Software Engineer', location: 'Punjab', type: 'Full-Time', description: 'Design, develop, and maintain software systems for various applications.' },
    { title: 'Cloud Architect', location: 'Rajasthan', type: 'Full-Time', description: 'Design cloud infrastructure and manage cloud services and environments.' },
    { title: 'JavaScript Developer', location: 'Goa', type: 'Part-Time', description: 'Build dynamic and interactive web pages using JavaScript and frameworks.' },
    { title: 'Database Administrator', location: 'Haryana', type: 'Full-Time', description: 'Manage and maintain databases, ensuring data security and integrity.' },
    { title: 'Cybersecurity Specialist', location: 'Goa', type: 'Remote', description: 'Protect systems, networks, and data from cyber threats.' },
    { title: 'AI Engineer', location: 'Himachal', type: 'Full-Time', description: 'Build AI models and systems to solve complex business problems.' },
    { title: 'Network Engineer', location: 'Gujarat', type: 'Full-Time', description: 'Design, implement, and maintain computer networks within organizations.' },
    { title: 'QA Engineer', location: 'Punjab', type: 'Part-Time', description: 'Test and ensure quality of software products through manual and automated testing.' },
    { title: 'Blockchain Developer', location: 'Jharkhand', type: 'Remote', description: 'Develop and maintain decentralized applications and blockchain platforms.' },
    { title: 'Graphic Designer', location: 'Kerala', type: 'Freelance', description: 'Create visual content for digital and print media, including websites and branding.' },
    { title: 'Content Writer', location: 'Rajasthan', type: 'Freelance', description: 'Write and edit content for websites, blogs, and marketing materials.' },
    { title: 'Marketing Manager', location: 'Goa', type: 'Full-Time', description: 'Develop and execute marketing strategies for company products and services.' },
    { title: 'Business Analyst', location: 'Punjab', type: 'Full-Time', description: 'Analyze business processes and suggest improvements to optimize efficiency.' },
    { title: 'Sales Engineer', location: 'Rajasthan', type: 'Full-Time', description: 'Support the sales team by providing technical knowledge and customer presentations.' },
    { title: 'System Administrator', location: 'Jharkhand', type: 'Full-Time', description: 'Maintain and manage IT infrastructure, servers, and systems for the organization.' }
];

// Function to display job listings
function displayJobListings(jobArray) {
    const jobListingsContainer = document.getElementById('job-listings');
    jobListingsContainer.innerHTML = ''; // Clear current listings

    if (jobArray.length === 0) {
        jobListingsContainer.innerHTML = '<p>No jobs found for the selected filters.</p>';
    }

    jobArray.forEach(job => {
        const jobCard = document.createElement('div');
        jobCard.classList.add('job-card');
        jobCard.innerHTML = `
            <h4>${job.title}</h4>
            <p class="location">Location: ${job.location}</p>
            <p class="type">${job.type}</p>
            <p>${job.description}</p><br><br>
            <button onclick="applyAction()" class="c1">Apply</button>
        `;
        jobListingsContainer.appendChild(jobCard);
    });
}

// Apply Action function
function applyAction() {
    // alert("ressOk ");
    if(confirm("press ok to register")){
        window.location.href="project2.html";
    }
}

// Apply Filters
function applyFilters() {
    const searchQuery = document.getElementById('job-search').value.toLowerCase();
    const locationFilter = document.getElementById('location-filter').value;
    const jobTypeFilter = document.getElementById('job-type-filter').value;

    const filteredJobs = jobs.filter(job => {
        const locationMatch = locationFilter === 'all' || job.location === locationFilter;
        const typeMatch = jobTypeFilter === 'all' || job.type === jobTypeFilter;
        const searchMatch = job.title.toLowerCase().includes(searchQuery) || job.description.toLowerCase().includes(searchQuery);
        return locationMatch && typeMatch && searchMatch;
    });

    displayJobListings(filteredJobs);
}

// Initial display of all jobs when the page loads
displayJobListings(jobs);

// Event listeners for filters
document.getElementById('job-search').addEventListener('input', applyFilters);
document.getElementById('location-filter').addEventListener('change', applyFilters);
document.getElementById('job-type-filter').addEventListener('change', applyFilters);
