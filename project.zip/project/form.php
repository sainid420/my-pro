<?php

$conn=mysqli_connect($host="localhost",$user="root",$password="")or die(mysqli_error($conn));
echo"database connected<br>";
$sql=mysqli_query($conn,"create database form")or die(mysqli_error($conn));
echo"database created <br>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* CSS styles for professional form design */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .registration-form {
            background-color: #fff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        h1 {
            text-align: center;
            color: #333;
            font-size: 2em;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
            color: #555;
        }

        input[type="text"], input[type="email"], input[type="date"], select {
            width: 100%;
            padding: 12px;
            margin: 8px 0 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            color: #333;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="email"]:focus, input[type="date"]:focus, select:focus {
            border-color: #4CAF50;
            outline: none;
        }

        input[type="radio"] {
            margin-right: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group-radio {
            margin-bottom: 20px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .form-group select {
            padding: 12px;
        }

        /* Adding spacing for radio buttons */
        .form-group-radio label {
            margin-right: 20px;
        }

        /* Improve the layout of the form */
        .form-group-radio {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .form-group select, .form-group input {
            box-sizing: border-box;
        }

        /* Mobile responsiveness */
        @media (max-width: 768px) {
            .registration-form {
                padding: 20px;
            }

            h1 {
                font-size: 1.5em;
            }

            button {
                padding: 10px 15px;
            }
        }

    </style>
</head>
<body>
    <div class="registration-form">
        <h1>Registration Form</h1>
        <form action="#" method="post">
            <!-- First Name -->
            <div class="form-group">
                <label for="firstname">First Name:</label>
                <input type="text" id="firstname" name="firstname" placeholder="First Name" required>
            </div>

            <!-- Last Name -->
            <div class="form-group">
                <label for="lastname">Last Name:</label>
                <input type="text" id="lastname" name="lastname" placeholder="Last Name" required>
            </div>

            <!-- Email -->
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Email" required>
            </div>

            <!-- Date of Birth -->
            <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="date" placeholder="Date of Birth" required>
            </div>

            <!-- Gender -->
            <div class="form-group-radio">
                <label>Gender:</label>
                <label>
                    <input type="radio" name="gender" value="Male"> Male
                </label>
                <label>
                    <input type="radio" name="gender" value="Female"> Female
                </label>
            </div>

            <!-- Choose Course -->
            <div class="form-group">
                <label for="course">Choose Course:</label>
                <select id="course" name="course" required>
                    <option value="">--Select--</option>
                    <option value="Frontend Developer">Frontend Developer</option>
                    <option value="Backend Developer">Backend Developer</option>
                    <option value="Full Stack Developer">Full Stack Developer</option>
                    <option value="UI/UX Designer">UI/UX Designer</option>
                    <option value="Product Manager">Product Manager</option>
                    <option value="Data Scientist">Data Scientist</option>
                    <option value="DevOps Engineer">DevOps Engineer</option>
                    <option value="Mobile App Developer">Mobile App Developer</option>
                    <option value="Software Engineer">Software Engineer</option>
                    <option value="Cloud Architect">Cloud Architect</option>
                    <option value="Javascript Developer">Javascript Developer</option>
                    <option value="Database Administrator">Database Administrator</option>
                    <option value="Cybersecurity Specialist">Cybersecurity Specialist</option>
                    <option value="AI Engineer">AI Engineer</option>
                    <option value="Network Engineer">Network Engineer</option>
                    <option value="QA Engineer">QA Engineer</option>
                    <option value="Blockchain Developer">Blockchain Developer</option>
                    <option value="Graphic Designer">Graphic Designer</option>
                    <option value="Content Writer">Content Writer</option>
                    <option value="Marketing Manager">Marketing Manager</option>
                    <option value="Business Analyst">Business Analyst</option>
                    <option value="Sales Manager">Sales Manager</option>
                    <option value="System Administrator">System Administrator</option>
                </select>
            </div>

            <!-- Location -->
            <div class="form-group">
                <label for="location">Location:</label>
                <select id="location" name="location" required>
                    <option value="">--Select--</option>
                    <option value="Himachal">Himachal</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Goa">Goa</option>
                    <option value="Rajasthan">Rajasthan</option>
                </select>
            </div>

            <!-- Submit Button -->
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
